/* DOROSYNC 웹 – 화면 로직 */
(function () {
  'use strict';
  const D = self.DATA, E = self.DoroEngine;
  const RES = E.RES;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const fmt = (n) => (isFinite(n) ? Math.round(n).toLocaleString('ko-KR') : '-');
  const won = (n) => fmt(n) + '원';
  const WD = ['일', '월', '화', '수', '목', '금', '토'];
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const KEY = 'dorosync.web.v1';

  /* ---------- 상태 ---------- */
  function todayStr() {
    const d = new Date();
    const p = (x) => String(x).padStart(2, '0');
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }
  function defaults() {
    return {
      S0: 467, T: 600, L0: 607, sortie: 5, start: todayStr(), G: -0.4, power: 1118437,
      boxes: [[0, 0, 0, 0, 15, 410], [7, 13, 0, 0, 15, 446], [1, 0, 50, 0, 1552, 1045]],
      loose: [7964, 46639976, 6083382],
      inc: JSON.parse(JSON.stringify(D.inc)),
      pk: JSON.parse(JSON.stringify(D.pk)),
      cfg: JSON.parse(JSON.stringify(D.cfg)),
    };
  }
  let st = defaults();
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const s = JSON.parse(raw);
      if (s && s.pk && s.pk.length === D.pk.length && s.inc && s.inc.length === D.inc.length) st = Object.assign(defaults(), s);
    }
  } catch (e) { /* 저장소를 못 쓰는 환경이면 무시 */ }
  let saveT = 0;
  function save() {
    clearTimeout(saveT);
    saveT = setTimeout(() => { try { localStorage.setItem(KEY, JSON.stringify(st)); } catch (e) { /* ignore */ } }, 200);
  }

  let M = null, TR = null; // 현재 모델/결과

  /* ---------- 날짜 ---------- */
  function dstr(d, withWd) {
    const t = new Date(M.startMs + (d - 1) * 86400000);
    const p = (x) => String(x).padStart(2, '0');
    return t.getUTCFullYear() + '-' + p(t.getUTCMonth() + 1) + '-' + p(t.getUTCDate()) + (withWd ? '(' + WD[t.getUTCDay()] + ')' : '');
  }

  /* ---------- 입력 폼 ---------- */
  function field(id, label, html, hint) {
    return '<div class="fld"><label for="' + id + '">' + label + '</label>' + html + (hint ? '<div class="hint" id="' + id + '-h">' + hint + '</div>' : '') + '</div>';
  }
  const num = (id, v, min, max, step) =>
    '<input type="number" id="' + id + '" value="' + (v === '' || v == null ? '' : v) + '" ' + (min != null ? 'min="' + min + '" ' : '') + (max != null ? 'max="' + max + '" ' : '') + 'step="' + (step || 'any') + '" inputmode="decimal">';

  function buildUser() {
    const gopt = [];
    for (let p = 0; p <= 45; p += 5) gopt.push('<option value="' + (-p / 100) + '"' + (Math.abs(st.G + p / 100) < 1e-9 ? ' selected' : '') + '>' + (p === 0 ? '0%' : '-' + p + '%') + '</option>');
    $('#f-user').innerHTML =
      field('u-S0', '현재 싱크로 레벨', num('u-S0', st.S0, 1, 999, 1), '200~999') +
      field('u-T', '목표 싱크로 레벨', num('u-T', st.T, 2, 1000, 1), '최대 1000') +
      field('u-L0', '전초기지 레벨', num('u-L0', st.L0, 1, 800, 1), '1~800') +
      field('u-sortie', '단기섬멸 횟수', num('u-sortie', st.sortie, 1, 11, 1), '1~11 (1회는 무료)') +
      field('u-start', '시작 날짜', '<input type="date" id="u-start" value="' + st.start + '">') +
      field('u-G', '투력차 (클리어 성향)', '<select id="u-G">' + gopt.join('') + '</select>', '0% ~ -45% (5% 단위)') +
      field('u-power', '현재 1군 전투력', num('u-power', st.power || '', 0, null, 1), '<span id="u-power-t">비우면 평균 유저 모델 사용</span>');
    const bind = (id, fn) => $('#' + id).addEventListener('input', (e) => { fn(e.target.value); onChange(); });
    bind('u-S0', (v) => (st.S0 = +v));
    bind('u-T', (v) => (st.T = +v));
    bind('u-L0', (v) => (st.L0 = +v));
    bind('u-sortie', (v) => (st.sortie = +v));
    bind('u-start', (v) => (st.start = v));
    bind('u-G', (v) => (st.G = +v));
    bind('u-power', (v) => (st.power = +v || 0));
  }

  const BNAMES = ['24h 상자 (개)', '12h 상자 (개)', '8h 상자 (개)', '4h 상자 (개)', '2h 상자 (개)', '1h 상자 (개)'];
  function buildStock() {
    let h = '<thead><tr><th>항목</th><th>코더 (코어더스트)</th><th>배데 (배틀데이터)</th><th>크레딧</th></tr></thead><tbody>';
    for (let i = 0; i < 6; i++) {
      h += '<tr><td>' + BNAMES[i] + '</td>';
      for (let k = 0; k < 3; k++) h += '<td>' + num('s-' + k + '-' + i, st.boxes[k][i], 0, null, 1) + '</td>';
      h += '</tr>';
    }
    h += '<tr><td>낱개 단위</td>';
    for (let k = 0; k < 3; k++) h += '<td>' + num('s-' + k + '-L', st.loose[k], 0, null, 1) + '</td>';
    h += '</tr></tbody><tfoot><tr><td>보유 합계 (낱개 환산)</td><td id="s-sum-0"></td><td id="s-sum-1"></td><td id="s-sum-2"></td></tr></tfoot>';
    $('#t-stock').innerHTML = h;
    $$('#t-stock input').forEach((el) => el.addEventListener('input', () => {
      const [, k, i] = el.id.split('-');
      const v = Math.max(0, +el.value || 0);
      if (i === 'L') st.loose[+k] = v; else st.boxes[+k][+i] = v;
      onChange();
    }));
  }

  function buildCfg() {
    const wd = ['월', '화', '수', '목', '금', '토', '일'].map((n, i) => '<option value="' + (i + 1) + '"' + (st.cfg.wk === i + 1 ? ' selected' : '') + '>' + n + '요일</option>').join('');
    $('#f-cfg').innerHTML =
      field('c-wk', '주간 패키지 구매 요일', '<select id="c-wk">' + wd + '</select>') +
      field('c-mday', '월간 패키지 구매일 (매월 N일)', num('c-mday', st.cfg.mday, 1, 28, 1)) +
      field('c-mlen', '월정액 적용 일수', num('c-mlen', st.cfg.mlen, 1, 60, 1), '만료 다음 날 자동 재구매') +
      field('c-per', '(기간) 패키지 주기 (일)', num('c-per', st.cfg.per, 1, 60, 1)) +
      field('c-r0', '재화선택 비율 · 코더', num('c-r0', st.cfg.ratio[0], 0, null, 'any'), '커스텀 패키지·월정액·백업마스터') +
      field('c-r1', '재화선택 비율 · 배데', num('c-r1', st.cfg.ratio[1], 0, null, 'any')) +
      field('c-r2', '재화선택 비율 · 크레딧', num('c-r2', st.cfg.ratio[2], 0, null, 'any'));
    const b = (id, f) => $('#' + id).addEventListener('input', (e) => { f(+e.target.value); onChange(); });
    b('c-wk', (v) => (st.cfg.wk = v));
    b('c-mday', (v) => (st.cfg.mday = v || 1));
    b('c-mlen', (v) => (st.cfg.mlen = v || 30));
    b('c-per', (v) => (st.cfg.per = v || 14));
    b('c-r0', (v) => (st.cfg.ratio[0] = v));
    b('c-r1', (v) => (st.cfg.ratio[1] = v));
    b('c-r2', (v) => (st.cfg.ratio[2] = v));
  }

  /* ---------- 패키지 표 ---------- */
  function buildPkg() {
    const det = $('#pk-detail').checked;
    let h = '<thead><tr><th>사용</th><th class="l">패키지</th><th>가격(원)</th><th>1만원당 환산h</th><th>구매 횟수</th><th>과금액(원)</th><th>최대 구매 횟수</th>';
    if (det) h += '<th>선택 재화</th><th>기준h</th><th>코더 h</th><th>배데 h</th><th>크레딧 h</th><th>코더 고정</th><th>배데 고정</th><th>크레딧 고정</th>';
    h += '</tr></thead><tbody>';
    st.pk.forEach((p, j) => {
      h += '<tr data-j="' + j + '"><td><input type="checkbox" data-f="use"' + (p.use ? ' checked' : '') + '></td>' +
        '<td class="name">' + esc(p.name) + '</td>' +
        '<td>' + num('', p.price, 0, null, 1).replace('id=""', 'data-f="price"') + '</td>' +
        '<td data-o="eff"></td><td data-o="cnt"></td><td data-o="bill"></td>' +
        '<td>' + '<input type="number" data-f="max" min="1" step="1" placeholder="제한 없음" value="' + (p.max || '') + '">' + '</td>';
      if (det) {
        h += '<td><select data-f="sel">' + ['', '코더', '배데', '크레딧'].map((o) => '<option value="' + o + '"' + (p.sel === o ? ' selected' : '') + '>' + (o || '-') + '</option>').join('') + '</select></td>';
        h += '<td><input type="number" data-f="base" min="0" step="any" value="' + (p.base || 0) + '"></td>';
        for (let k = 0; k < 3; k++) h += '<td><input type="number" data-f="h' + k + '" min="0" step="any" value="' + (p.h[k] || 0) + '"' + (p.sel ? ' disabled' : '') + '></td>';
        for (let k = 0; k < 3; k++) h += '<td><input type="number" data-f="fx' + k + '" min="0" step="any" value="' + (p.fx[k] || 0) + '"></td>';
      }
      h += '</tr>';
    });
    h += '</tbody><tfoot><tr><td></td><td class="l">합계</td><td></td><td></td><td id="pk-sum-cnt"></td><td id="pk-sum-bill"></td><td></td></tr></tfoot>';
    $('#t-pkg').innerHTML = h;
  }
  $('#t-pkg').addEventListener('input', (e) => {
    const el = e.target, tr = el.closest('tr[data-j]');
    if (!tr || !el.dataset.f) return;
    const p = st.pk[+tr.dataset.j], f = el.dataset.f;
    if (f === 'use') p.use = el.checked;
    else if (f === 'price') p.price = Math.max(0, +el.value || 0);
    else if (f === 'max') p.max = +el.value > 0 ? Math.floor(+el.value) : null;
    else if (f === 'sel') { p.sel = el.value; buildPkg(); }
    else if (f === 'base') p.base = +el.value || 0;
    else if (f[0] === 'h') p.h[+f[1]] = +el.value || 0;
    else if (f.slice(0, 2) === 'fx') p.fx[+f[2]] = +el.value || 0;
    onChange();
  });
  $('#pk-detail').addEventListener('change', () => { buildPkg(); renderOut(); });
  $('#pk-all').addEventListener('click', () => { st.pk.forEach((p) => (p.use = true)); buildPkg(); onChange(); });
  $('#pk-none').addEventListener('click', () => { st.pk.forEach((p) => (p.use = false)); buildPkg(); onChange(); });

  /* ---------- 일일 수급 표 ---------- */
  function buildInc() {
    let h = '<thead><tr><th>사용</th><th class="l">항목</th><th>주기(일)</th><th>코더 h</th><th>코더 고정</th><th>배데 h</th><th>배데 고정</th><th>크레딧 h</th><th>크레딧 고정</th><th>일일 코더</th><th>일일 배데</th><th>일일 크레딧</th></tr></thead><tbody>';
    st.inc.forEach((r, i) => {
      h += '<tr data-i="' + i + '"><td><input type="checkbox" data-f="use"' + (r.use ? ' checked' : '') + '></td><td class="name">' + esc(r.name) + '</td>';
      h += '<td><input type="number" data-f="cyc" min="1" step="any" value="' + r.cyc + '"></td>';
      for (let k = 0; k < 3; k++) {
        if (r.sortie) h += '<td data-o="sh' + k + '"></td>';
        else h += '<td><input type="number" data-f="h' + k + '" min="0" step="any" value="' + r.h[k] + '"></td>';
        h += '<td><input type="number" data-f="fx' + k + '" min="0" step="any" value="' + r.fx[k] + '"></td>';
      }
      h += '<td data-o="d0"></td><td data-o="d1"></td><td data-o="d2"></td></tr>';
    });
    h += '</tbody><tfoot><tr><td></td><td class="l">합계</td><td></td><td colspan="6"></td><td id="inc-s0"></td><td id="inc-s1"></td><td id="inc-s2"></td></tr></tfoot>';
    $('#t-inc').innerHTML = h;
  }
  $('#t-inc').addEventListener('input', (e) => {
    const el = e.target, tr = el.closest('tr[data-i]');
    if (!tr || !el.dataset.f) return;
    const r = st.inc[+tr.dataset.i], f = el.dataset.f;
    if (f === 'use') r.use = el.checked;
    else if (f === 'cyc') r.cyc = +el.value > 0 ? +el.value : 1;
    else if (f[0] === 'h') r.h[+f[1]] = +el.value || 0;
    else r.fx[+f[2]] = +el.value || 0;
    onChange();
  });

  /* ---------- 차트 ---------- */
  function niceTicks(lo, hi, n) {
    if (hi <= lo) hi = lo + 1;
    const raw = (hi - lo) / n, p = Math.pow(10, Math.floor(Math.log10(raw)));
    const f = raw / p, step = (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * p;
    const a = Math.floor(lo / step) * step, b = Math.ceil(hi / step) * step, t = [];
    for (let v = a; v <= b + step * 0.5; v += step) t.push(+v.toFixed(10));
    return t;
  }
  /** opts: {series:[{name,color,pts:[[x,y]],dots?}], xl, yl, xf, yf, tip(i,s), onPick(i)} */
  function chart(el, o) {
    const W = 560, H = 270, ml = 58, mr = 12, mt = 10, mb = 34;
    let xs = [], ys = [];
    o.series.forEach((s) => s.pts.forEach((p) => { xs.push(p[0]); ys.push(p[1]); }));
    if (!xs.length) { el.innerHTML = '<p class="muted">표시할 데이터가 없습니다.</p>'; return; }
    const yt = niceTicks(Math.min(...ys), Math.max(...ys), 5), xt = niceTicks(Math.min(...xs), Math.max(...xs), 6);
    const x0 = xt[0], x1 = xt[xt.length - 1], y0 = yt[0], y1 = yt[yt.length - 1];
    const X = (v) => ml + ((v - x0) / (x1 - x0 || 1)) * (W - ml - mr);
    const Y = (v) => H - mb - ((v - y0) / (y1 - y0 || 1)) * (H - mt - mb);
    let g = '';
    yt.forEach((v) => { g += '<line class="gl" x1="' + ml + '" x2="' + (W - mr) + '" y1="' + Y(v) + '" y2="' + Y(v) + '"/><text class="tx" x="' + (ml - 6) + '" y="' + (Y(v) + 4) + '" text-anchor="end">' + (o.yf ? o.yf(v) : fmt(v)) + '</text>'; });
    xt.forEach((v) => { g += '<text class="tx" x="' + X(v) + '" y="' + (H - mb + 15) + '" text-anchor="middle">' + (o.xf ? o.xf(v) : fmt(v)) + '</text>'; });
    g += '<line class="ax" x1="' + ml + '" x2="' + (W - mr) + '" y1="' + (H - mb) + '" y2="' + (H - mb) + '"/>';
    if (o.xl) g += '<text class="tx" x="' + (W - mr) + '" y="' + (H - 4) + '" text-anchor="end">' + o.xl + '</text>';
    o.series.forEach((s, si) => {
      let d = '';
      s.pts.forEach((p, i) => {
        if (s.step && i) d += 'L' + X(p[0]).toFixed(1) + ',' + Y(s.pts[i - 1][1]).toFixed(1);
        d += (i ? 'L' : 'M') + X(p[0]).toFixed(1) + ',' + Y(p[1]).toFixed(1);
      });
      g += '<path d="' + d + '" fill="none" stroke="' + s.color + '" stroke-width="2" stroke-linejoin="round"/>';
      if (s.dots) s.pts.forEach((p, i) => { g += '<circle data-i="' + i + '" cx="' + X(p[0]).toFixed(1) + '" cy="' + Y(p[1]).toFixed(1) + '" r="' + (s.sel === i ? 6 : 3.5) + '" fill="' + (s.sel === i ? 'var(--c2)' : s.color) + '" stroke="var(--card)" stroke-width="1.5"/>'; });
    });
    g += '<line id="cx" class="ax" y1="' + mt + '" y2="' + (H - mb) + '" style="display:none"/>';
    let lg = '';
    if (o.series.length > 1) lg = '<div class="legend">' + o.series.map((s) => '<span><i style="background:' + s.color + '"></i>' + s.name + '</span>').join('') + '</div>';
    el.innerHTML = lg + '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + (o.label || '그래프') + '">' + g + '</svg><div class="tip"></div>';
    const svg = $('svg', el), tip = $('.tip', el), cx = $('#cx', el);
    const base = o.series[0].pts;
    function near(ev) {
      const r = svg.getBoundingClientRect();
      const px = ((ev.clientX - r.left) / r.width) * W;
      let bi = 0, bd = 1e18;
      base.forEach((p, i) => { const d = Math.abs(X(p[0]) - px); if (d < bd) { bd = d; bi = i; } });
      return bi;
    }
    svg.addEventListener('mousemove', (ev) => {
      const i = near(ev), p = base[i], r = svg.getBoundingClientRect();
      cx.setAttribute('x1', X(p[0])); cx.setAttribute('x2', X(p[0])); cx.style.display = '';
      tip.innerHTML = o.tip(i); tip.style.left = (X(p[0]) / W) * r.width + 'px'; tip.style.top = (Y(p[1]) / H) * r.height + (lg ? 22 : 0) + 'px'; tip.classList.add('on');
    });
    svg.addEventListener('mouseleave', () => { tip.classList.remove('on'); cx.style.display = 'none'; });
    if (o.onPick) svg.addEventListener('click', (ev) => o.onPick(near(ev)));
  }

  /* ---------- 계산 & 렌더 ---------- */
  let tmr = 0;
  function onChange() { save(); clearTimeout(tmr); tmr = setTimeout(recalc, 90); }

  function problems() {
    const p = [];
    if (!(st.S0 >= 1 && st.S0 < 1000)) p.push('현재 싱크로 레벨은 1~999 사이여야 합니다.');
    if (!(st.T > st.S0)) p.push('목표 싱크로 레벨이 현재보다 커야 합니다.');
    if (st.T > 1000) p.push('목표 싱크로 레벨은 최대 1000입니다.');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(st.start)) p.push('시작 날짜를 입력하세요.');
    return p;
  }

  function recalc() {
    const pr = problems();
    const box = $('#result');
    if (pr.length) {
      M = TR = null;
      box.innerHTML = '<p class="bad">' + pr.join('<br>') + '</p>';
      return;
    }
    const warn = [];
    if (st.S0 < 200) warn.push('200 싱크로 레벨 미만은 레벨업 비용표가 없어 정확하지 않습니다(1군의 오버작+소장품+스킬작 완료 후 사용).');
    M = E.buildModel(st, D);
    TR = E.simulate(M, null, true);
    const t = TR;
    const first = t.first;
    const allOk = first.every((x) => x > 0);
    const daysAll = allOk ? Math.max(...first) : 0;
    // 구매 횟수
    const cnt = st.pk.map(() => 0);
    t.rows.forEach((r) => r.flags.forEach((f, j) => (cnt[j] += f)));
    TR.cnt = cnt;
    const bill = t.bill;
    const lEnd = t.rows.length ? t.rows[t.rows.length - 1].L : st.L0;

    let h = '<div class="kpis">';
    h += '<div class="kpi' + (allOk ? '' : ' bad') + '"><small>전체 목표 달성</small><b>' + (allOk ? daysAll + '일' : '미도달') + '</b><span>' + (allOk ? dstr(daysAll, true) : '1500일 안에 도달하지 못했습니다') + '</span></div>';
    h += '<div class="kpi"><small>총 과금액</small><b>' + won(bill) + '</b><span>' + (allOk ? '월 환산 약 ' + won(bill / Math.max(1, daysAll) * 30) : '1500일까지 누적한 값') + '</span></div>';
    h += '<div class="kpi"><small>전초기지 Lv</small><b>' + st.L0 + ' → ' + lEnd + '</b><span>보스 클리어로 상승</span></div>';
    h += '</div><div class="tscroll"><table class="tbl"><thead><tr><th class="l">재화</th><th>필요량</th><th>도달 일수</th><th>도달 날짜</th></tr></thead><tbody>';
    RES.forEach((n, k) => {
      h += '<tr><td class="l">' + n + '</td><td>' + fmt(M.Need[k]) + '</td><td>' + (first[k] ? first[k] + '일' : '미도달') + '</td><td>' + (first[k] ? dstr(first[k], true) : '-') + '</td></tr>';
    });
    h += '</tbody></table></div>';
    const buys = st.pk.map((p, j) => ({ p, c: cnt[j] })).filter((x) => x.c > 0);
    if (buys.length) {
      h += '<h3 class="mt">구매 내역</h3><div class="tscroll"><table class="tbl compact"><tbody>' +
        buys.map((x) => '<tr><td class="l name">' + esc(x.p.name) + '</td><td>' + x.c + '회</td><td>' + won(x.c * x.p.price) + '</td></tr>').join('') + '</tbody></table></div>';
    } else h += '<p class="muted mt">선택된 구매 패키지가 없습니다(일일 수급만 반영).</p>';
    if (warn.length) h += '<p class="note warn mt">' + warn.join('<br>') + '</p>';
    box.innerHTML = h;
    // 투력 보정 문구
    const pt = $('#u-power-t');
    if (pt) pt.textContent = st.power > 0 ? '모델 대비 ' + ((st.power / M.cpsAt(M.S0) - 1) * 100 >= 0 ? '+' : '') + ((st.power / M.cpsAt(M.S0) - 1) * 100).toFixed(1) + '% 보정' : '비우면 평균 유저 모델 사용';
    // 보유 합계
    for (let k = 0; k < 3; k++) {
      const el = $('#s-sum-' + k);
      if (el) el.textContent = fmt(M.Uh0[k] * M.v1h0[k] + (st.loose[k] || 0));
    }
    // 차트
    const days = t.rows;
    chart($('#ch-lv'), {
      label: '싱크로·전초기지 레벨', xl: '일차',
      series: [
        { name: '싱크로 Lv', color: 'var(--c1)', pts: [[0, st.S0]].concat(days.map((r) => [r.t, r.S])) },
        { name: '전초기지 Lv', color: 'var(--c2)', pts: [[0, st.L0]].concat(days.map((r) => [r.t, r.L])) },
      ],
      tip: (i) => (i === 0 ? '시작' : i + '일차 · ' + dstr(i)) + '<br>싱크로 ' + (i ? days[i - 1].S : st.S0) + ' / 전초기지 ' + (i ? days[i - 1].L : st.L0),
    });
    chart($('#ch-bill'), {
      label: '누적 과금액', xl: '일차', yf: (v) => (v >= 10000 ? fmt(v / 10000) + '만' : fmt(v)),
      series: [{ name: '누적 과금액', color: 'var(--c3)', pts: [[0, 0]].concat(days.map((r) => [r.t, r.billCum])) }],
      tip: (i) => (i === 0 ? '시작' : i + '일차 · ' + dstr(i)) + '<br>누적 ' + won(i ? days[i - 1].billCum : 0),
    });
    renderOut();
  }

  /** 입력 이외의 표(패키지 결과열, 수급, 일자별, 보스) */
  function renderOut() {
    if (!M) return;
    // 패키지 표
    let sc = 0, sb = 0;
    $$('#t-pkg tr[data-j]').forEach((tr) => {
      const j = +tr.dataset.j, p = M.Pk[j];
      let v = 0;
      for (let k = 0; k < 3; k++) v += (p.H[k] * (p.per === '월정액' ? M.cfg.mlen : 1)) / (M.cfg.ratio[k] || 1);
      tr.querySelector('[data-o=eff]').textContent = (v / p.price * 10000).toFixed(1);
      const c = TR.cnt[j];
      tr.querySelector('[data-o=cnt]').textContent = c ? c : '-';
      tr.querySelector('[data-o=bill]').textContent = c ? fmt(c * p.price) : '-';
      sc += c; sb += c * p.price;
      // 재화선택형 패키지의 h 표시값 갱신
      if (st.pk[j].sel) for (let k = 0; k < 3; k++) { const inp = tr.querySelector('[data-f=h' + k + ']'); if (inp) inp.value = p.H[k]; }
    });
    if ($('#pk-sum-cnt')) { $('#pk-sum-cnt').textContent = sc; $('#pk-sum-bill').textContent = fmt(sb); }
    // 수급 표
    const v1 = M.v1h0;
    const sums = [0, 0, 0];
    $$('#t-inc tr[data-i]').forEach((tr) => {
      const r = st.inc[+tr.dataset.i], cyc = r.cyc > 0 ? r.cyc : 1;
      for (let k = 0; k < 3; k++) {
        const h = r.sortie ? 2 * st.sortie : r.h[k];
        const v = r.use ? (h * v1[k] + r.fx[k]) / cyc : 0;
        sums[k] += v;
        tr.querySelector('[data-o=d' + k + ']').textContent = fmt(v);
        const sh = tr.querySelector('[data-o=sh' + k + ']'); if (sh) sh.textContent = h;
      }
    });
    for (let k = 0; k < 3; k++) $('#inc-s' + k).textContent = fmt(sums[k]);
    if ($('#tab-daily').classList.contains('on')) renderDaily();
    if ($('#tab-boss').classList.contains('on')) renderBoss();
  }

  function buyText(r) {
    const a = [];
    r.flags.forEach((f, j) => { if (f) a.push(st.pk[j].name.replace(/^(\(기간\)|월간|주간|일일)\s*/, '').replace(' (월정액)', '')); });
    return a.join(', ');
  }
  function dailyRows() {
    const buyonly = $('#d-buyonly').checked;
    return TR.rows.filter((r) => !buyonly || r.bill > 0);
  }
  function renderDaily() {
    if (!TR) return;
    const det = $('#d-detail').checked;
    let h = '<thead><tr><th>일차</th><th class="l">날짜</th><th class="l">구매 패키지</th><th>일일 과금</th><th>누적 과금</th><th>코더 획득</th><th>배데 획득</th><th>크레딧 획득</th><th>싱크로 Lv</th><th>전초기지 Lv</th><th>예상 전투력</th>';
    if (det) h += '<th>코더 누적</th><th>배데 누적</th><th>크레딧 누적</th><th>코더 개봉</th><th>배데 개봉</th><th>크레딧 개봉</th><th>코더 보관h</th><th>배데 보관h</th><th>크레딧 보관h</th>';
    h += '</tr></thead><tbody>';
    const last = TR.rows.length ? TR.rows[TR.rows.length - 1].t : 0;
    dailyRows().forEach((r) => {
      h += '<tr class="' + (r.bill > 0 ? 'buy' : '') + (r.t === last && TR.days < 9999 ? ' end' : '') + '"><td>' + r.t + '</td><td class="l">' + dstr(r.t, true) + '</td><td class="l name">' + esc(buyText(r)) + '</td><td>' + (r.bill ? fmt(r.bill) : '-') + '</td><td>' + fmt(r.billCum) + '</td>' +
        r.acq.map((x) => '<td>' + fmt(x) + '</td>').join('') + '<td>' + r.S + '</td><td>' + r.L + '</td><td>' + fmt(r.power) + '</td>';
      if (det) h += r.cum.map((x) => '<td>' + fmt(x) + '</td>').join('') + r.open.map((x) => '<td>' + fmt(x) + '</td>').join('') + r.hold.map((x) => '<td>' + fmt(x) + '</td>').join('');
      h += '</tr>';
    });
    $('#t-daily').innerHTML = h + '</tbody>';
  }
  $('#d-detail').addEventListener('change', renderDaily);
  $('#d-buyonly').addEventListener('change', renderDaily);
  $('#d-csv').addEventListener('click', () => {
    if (!TR) return;
    const head = ['일차', '날짜', '구매 패키지', '일일 과금', '누적 과금', '코더 획득', '배데 획득', '크레딧 획득', '싱크로 Lv', '전초기지 Lv', '예상 전투력'];
    const rows = TR.rows.map((r) => [r.t, dstr(r.t), '"' + buyText(r).replace(/"/g, '""') + '"', r.bill, r.billCum, Math.round(r.acq[0]), Math.round(r.acq[1]), Math.round(r.acq[2]), r.S, r.L, Math.round(r.power)]);
    const csv = '﻿' + [head].concat(rows).map((r) => r.join(',')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    a.download = 'dorosync_daily.csv';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  });

  function renderBoss() {
    if (!TR) return;
    const rows = E.bossTable(M, TR);
    let h = '<thead><tr><th>순서</th><th class="l">모드</th><th class="l">보스</th><th>기준 전투력</th><th>판정 투력</th><th>클리어 예상 날짜</th><th>일차</th><th>예상 싱크로 Lv</th><th>예상 투력</th></tr></thead><tbody>';
    rows.forEach((b) => {
      const dd = b.day === null ? '미도달' : b.day === 0 ? 'CLEAR' : dstr(b.day, true);
      h += '<tr><td>' + b.no + '</td><td class="l">' + b.mode + '</td><td class="l">' + esc(b.name) + '</td><td>' + fmt(b.base) + '</td><td>' + fmt(b.judge) + '</td><td class="' + (b.day === null ? 'bad' : '') + '">' + dd + '</td><td>' + (b.day === null || b.day === 0 ? '-' : b.day) + '</td><td>' + (b.S == null ? '-' : b.S) + '</td><td>' + (b.P == null ? '-' : fmt(b.P)) + '</td></tr>';
    });
    $('#t-boss').innerHTML = h + '</tbody>';
  }

  /* ---------- 최적 조합 ---------- */
  let optMode = '1';
  function buildOpt() {
    let nopt = '';
    for (let n = 6; n <= 20; n++) nopt += '<option value="' + n + '"' + (n === 13 ? ' selected' : '') + '>' + n + '개 (' + Math.pow(2, n).toLocaleString('ko-KR') + '가지)</option>';
    $('#f-opt').innerHTML =
      field('o-n', '후보 패키지 수 (효율 상위 N개)', '<select id="o-n">' + nopt + '</select>', '15개 이상은 시간이 오래 걸립니다') +
      field('o-mode', '탐색 방식', '<select id="o-mode"><option value="1">과금 한도 안에서 가장 빠른 조합</option><option value="2">목표 일수 안에 도달하는 최소 비용 조합</option><option value="3">비용–일수 곡선만 보기</option></select>') +
      '<div class="fld" id="o-valw">' + '<label for="o-val" id="o-val-l">과금 한도(원)</label><input type="number" id="o-val" min="0" step="10000" value="800000"></div>';
    $('#o-mode').addEventListener('change', (e) => {
      optMode = e.target.value;
      $('#o-valw').style.display = optMode === '3' ? 'none' : '';
      $('#o-val-l').textContent = optMode === '1' ? '과금 한도(원)' : '목표 일수(일)';
      $('#o-val').value = optMode === '1' ? 800000 : 100;
      $('#o-val').step = optMode === '1' ? 10000 : 1;
    });
    $('#opt-run').addEventListener('click', runOpt);
  }

  let optRun = 0, OPT = null;
  function runOpt() {
    if (!M) { $('#opt-status').textContent = '입력을 먼저 확인하세요.'; return; }
    const nc = +$('#o-n').value;
    const rank = E.rankPackages(M);
    const cand = rank.slice(0, nc).map((x) => x.j);
    const snap = JSON.parse(JSON.stringify(st));
    $('#opt-cands-card').hidden = false;
    $('#opt-cands').innerHTML = cand.map((j, i) => '<span class="chip"><b>' + (i + 1) + '</b>' + esc(M.Pk[j].name) + ' · ' + won(M.Pk[j].price) + '</span>').join('');
    const total = Math.pow(2, nc), id = ++optRun;
    const btn = $('#opt-run'), bar = $('#opt-bar'), fill = $('i', bar), status = $('#opt-status');
    btn.disabled = true; bar.hidden = false; fill.style.width = '0'; $('#opt-out').hidden = true;
    const t0 = performance.now();
    let done = 0;
    const finish = (list) => {
      if (id !== optRun) return;
      list.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
      const par = [];
      let bd = 1e9;
      list.forEach((r) => { if (r[1] < bd) { par.push(r); bd = r[1]; } });
      btn.disabled = false; bar.hidden = true;
      status.textContent = '계산 완료 · ' + ((performance.now() - t0) / 1000).toFixed(1) + '초 · ' + total.toLocaleString('ko-KR') + '가지';
      showOpt(par, cand, snap);
    };
    const prog = (n) => { done += n; fill.style.width = Math.min(100, (done / total) * 100) + '%'; status.textContent = '계산 중… ' + Math.min(100, Math.round((done / total) * 100)) + '%'; };
    let workers = [];
    const inline = () => {
      workers.forEach((w) => w.terminate()); workers = [];
      done = 0;
      const m = E.buildModel(snap, D), np = m.Pk.length, use = new Array(np).fill(false), R = [];
      let mask = 0;
      (function step() {
        if (id !== optRun) return;
        const end = performance.now() + 40;
        let c = 0;
        while (mask < total && performance.now() < end) {
          for (let j = 0; j < np; j++) use[j] = false;
          for (let b = 0; b < nc; b++) if ((mask >> b) & 1) use[cand[b]] = true;
          const r = E.simulate(m, use, false);
          if (r.days < 9999) R.push([r.bill, r.days, mask]);
          mask++; c++;
        }
        prog(c);
        if (mask < total) setTimeout(step, 0); else finish(R);
      })();
    };
    let nw = Math.max(1, Math.min(8, (navigator.hardwareConcurrency || 2) - 1));
    if (total < 4096) nw = 1;
    try {
      const results = [];
      let finished = 0;
      for (let w = 0; w < nw; w++) {
        const wk = new Worker('worker.js');
        workers.push(wk);
        wk.onmessage = (e) => {
          if (id !== optRun) { wk.terminate(); return; }
          if (e.data.type === 'progress') prog(e.data.n);
          else {
            results.push(...e.data.pareto);
            wk.terminate();
            if (++finished === nw) finish(results);
          }
        };
        wk.onerror = () => { if (id === optRun && workers.length) inline(); };
        wk.postMessage({ inp: snap, cand, w, nw });
      }
    } catch (err) { inline(); }
  }

  function describe(mask, cand) {
    const a = [];
    cand.forEach((j, b) => { if ((mask >> b) & 1) a.push(j); });
    return a;
  }

  function showOpt(par, cand, snap) {
    $('#opt-out').hidden = false;
    if (!par.length) { $('#opt-best').innerHTML = '<p class="bad">1500일 안에 목표에 도달하는 조합이 없습니다.</p>'; $('#t-pareto').innerHTML = ''; $('#ch-opt').innerHTML = ''; $('#opt-detail').innerHTML = ''; return; }
    OPT = { par, cand, snap, sel: 0 };
    const mode = optMode, val = +$('#o-val').value;
    let best = -1;
    if (mode === '1') par.forEach((r, i) => { if (r[0] <= val) best = i; });
    else if (mode === '2') { for (let i = 0; i < par.length; i++) if (par[i][1] <= val) { best = i; break; } }
    const startMs = M.startMs;
    const dd = (d) => { const t = new Date(startMs + (d - 1) * 86400000); return t.getUTCFullYear() + '-' + String(t.getUTCMonth() + 1).padStart(2, '0') + '-' + String(t.getUTCDate()).padStart(2, '0'); };
    let b = '';
    if (mode === '3') b = '<div class="best">아래 곡선에서 원하는 지점을 눌러 구성을 확인하세요.</div>';
    else if (best < 0) b = '<div class="best"><b class="bad">조건을 만족하는 조합이 없습니다.</b><br>' + (mode === '1' ? '아무것도 사지 않을 때(0원)도 한도 안에서 도달하지 못합니다.' : '후보를 늘리거나 목표 일수를 늘려 보세요.') + '</div>';
    else {
      const r = par[best];
      b = '<div class="best"><span class="muted">추천 조합</span><br><b class="big">' + r[1] + '일 (' + dd(r[1]) + ' 도달) · 총 과금 ' + won(r[0]) + '</b></div>';
      OPT.sel = best;
    }
    $('#opt-best').innerHTML = b;
    let h = '<thead><tr><th>총 과금</th><th>일수</th><th>도달 날짜</th><th>패키지 수</th></tr></thead><tbody>';
    par.forEach((r, i) => {
      h += '<tr class="click" data-i="' + i + '"><td>' + won(r[0]) + '</td><td>' + r[1] + '일</td><td>' + dd(r[1]) + '</td><td>' + describe(r[2], cand).length + '개</td></tr>';
    });
    $('#t-pareto').innerHTML = h + '</tbody>';
    selectOpt(OPT.sel, true);
  }

  function selectOpt(i, noScroll) {
    if (!OPT) return;
    OPT.sel = i;
    const par = OPT.par, r = par[i], list = describe(r[2], OPT.cand);
    $$('#t-pareto tr[data-i]').forEach((tr) => tr.classList.toggle('sel', +tr.dataset.i === i));
    chart($('#ch-opt'), {
      label: '비용-일수 곡선', xl: '총 과금(만원)', xf: (v) => fmt(v), yf: (v) => v + '일',
      series: [{ name: '최적 곡선', color: 'var(--c1)', step: true, dots: true, sel: i, pts: par.map((p) => [p[0] / 10000, p[1]]) }],
      tip: (k) => won(par[k][0]) + ' · ' + par[k][1] + '일 · ' + describe(par[k][2], OPT.cand).length + '개',
      onPick: (k) => selectOpt(k),
    });
    // 구성 + 구매 횟수 (해당 조합을 한 번 더 시뮬레이션)
    const m = E.buildModel(OPT.snap, D);
    const use = new Array(m.Pk.length).fill(false);
    list.forEach((j) => (use[j] = true));
    const tr = E.simulate(m, use, true);
    const cnt = m.Pk.map(() => 0);
    tr.rows.forEach((x) => x.flags.forEach((f, j) => (cnt[j] += f)));
    let h = '<b>' + won(r[0]) + ' · ' + r[1] + '일</b><ul>';
    if (!list.length) h += '<li>구매 없음 (일일 수급만)</li>';
    list.forEach((j) => { h += '<li>' + esc(m.Pk[j].name) + ' <span class="muted">· ' + cnt[j] + '회 · ' + won(cnt[j] * m.Pk[j].price) + '</span></li>'; });
    h += '</ul><div class="row-ctl mt"><button class="primary" id="opt-apply" type="button">이 조합을 패키지 설정에 적용</button></div><p class="muted" id="opt-applied"></p>';
    $('#opt-detail').innerHTML = h;
    $('#opt-apply').addEventListener('click', () => {
      st.pk.forEach((p, j) => (p.use = use[j]));
      buildPkg(); onChange();
      $('#opt-applied').textContent = '적용했습니다. [입력·결과]와 [패키지] 탭에서 확인하세요.';
    });
  }
  $('#t-pareto').addEventListener('click', (e) => {
    const tr = e.target.closest('tr[data-i]');
    if (tr) selectOpt(+tr.dataset.i);
  });

  /* ---------- 계산 규칙 ---------- */
  $('#rules').innerHTML = [
    '<h2>계산 규칙</h2>',
    '<h3>기본 흐름</h3><ul><li>시작 날짜를 1일차로 보고, 그날 구매한 일일 패키지와 기본 수급재화를 1일차부터 반영합니다.</li><li>매일 (당일 획득 재화 + 보관 상자를 당일 전초기지 Lv의 1h 값으로 환산한 값)으로 올릴 수 있는 싱크로 레벨을 구하고, 그 레벨까지 모자란 재화만큼만 상자를 엽니다. 남은 상자는 보관되어 전초기지 Lv이 오른 뒤 더 높은 가치로 쓰입니다.</li><li>어느 한 재화가 부족하면 가장 부족한 재화가 레벨업을 막습니다(코더·배데·크레딧 중 최소).</li><li>도달 판정은 해당일 종료 시점의 누적 지급량 ≥ 필요량입니다. 최대 1500일까지 계산합니다.</li></ul>',
    '<h3>패키지 구매</h3><ul><li>주기는 이름 앞머리로 판정합니다: 일일 / 주간 / 월간 / (기간) / 이름에 (월정액)이 있으면 월정액.</li><li>주간은 설정한 요일, 월간은 매월 N일, (기간)은 시작일부터 N일 간격, 월정액은 시작일부터 적용 일수마다 구매합니다(만료 다음 날 자동 재구매).</li><li>패키지가 주는 재화가 <b>모두</b> 목표에 도달하면 그 패키지는 더 구매하지 않습니다(과금 최소화).</li><li>재화선택형(커스텀 패키지, 월정액, 백업마스터)은 선택한 재화 하나에 기준h × 비율을 지급합니다. 기본 비율은 코더 1 : 배데 1 : 크레딧 3입니다.</li><li>최대 구매 횟수를 넣으면 그 횟수까지만 구매합니다(월정액은 시작 횟수 기준).</li></ul>',
    '<h3>전초기지 레벨 · 보스 클리어</h3><ul><li>예상 전투력 = 평균 유저 전투력표(싱크로 Lv별) × 1군 전투력 보정계수. 1군 전투력을 입력하면 현재 싱크로 기준으로 곡선 전체가 보정됩니다.</li><li>예상 전투력 ≥ 보스 판정 투력 × (1+투력차)이면 클리어로 봅니다. 보스 트라이는 매일 한다고 가정합니다.</li><li>전초기지 Lv = 1 + 내림((노말 클리어 스테이지 + 하드 클리어 스테이지) ÷ 5). 챕터는 모드별 순서대로만 열리므로 같은 모드에서 앞선 보스의 판정 투력 최댓값을 씁니다.</li><li>방지턱(하드 15~50장 보스)은 enikk KR 최저 20위 평균 전투력 기준 보정계수를 반영합니다. 노말 방지턱은 하드 계수를 준용한 추정입니다.</li><li>전초기지 Lv이 오르면 다음 날부터 재화상자 가치와 일일 수급량이 늘어납니다.</li></ul>',
    '<h3>한계점</h3><ul><li>결과는 \'유저가 매일 최적으로 보스를 잡는다\'는 가정의 빠른 쪽(낙관적) 추정입니다. 실제는 더 오래 걸릴 수 있습니다.</li><li>예상 전투력은 평균 유저 기준이며 개인 차이가 ±6% 정도 납니다. 600레벨 이상은 실제 기록이 적어 더 불확실합니다.</li><li>파견 리롤 X, 일반상점 쥬얼 구매 X 가정입니다.</li><li>이벤트·파견·퀘스트 수급은 연평균 고정값이라 이벤트가 몰리는 시기를 반영하지 못합니다.</li><li>보스가 아닌 일반 스테이지의 방지턱과 팝업 보상(레벨 달성, 타워 클리어)은 반영하지 못합니다.</li><li>200 싱크로 레벨 미만은 사용할 수 없습니다(1군의 오버작+소장품+스킬작이 완료되어야 합니다).</li><li>사용 순서: 보유 상자로 가능한 레벨업을 먼저 끝낸 상태에서 계산을 시작하는 것을 전제로 합니다.</li></ul>',
    '<h3>최적 조합 탐색</h3><ul><li>효율 순위는 코더:배데:크레딧 비율(기본 1:1:3)로 환산한 지급 h를 가격으로 나눈 값(월정액은 적용 일수 곱)입니다. 고정 재화는 제외합니다.</li><li>상위 N개 후보의 모든 구매 여부 조합을 계산하고, 비용이 같으면 가장 빠른 조합, 비용이 늘어도 일수가 줄지 않는 조합은 제외해 곡선을 만듭니다.</li></ul>',
  ].join('');

  /* ---------- 탭 ---------- */
  function showTab(name) {
    $$('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
    $$('.tab').forEach((s) => s.classList.toggle('on', s.id === 'tab-' + name));
    if (name === 'daily') renderDaily();
    if (name === 'boss') renderBoss();
    try { history.replaceState(null, '', '#' + name); } catch (e) { /* ignore */ }
  }
  $('#tabs').addEventListener('click', (e) => { const b = e.target.closest('button[data-tab]'); if (b) showTab(b.dataset.tab); });
  $('#btn-reset').addEventListener('click', () => {
    if (!confirm('입력값을 모두 처음 상태로 되돌릴까요?')) return;
    st = defaults();
    try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ }
    init();
  });

  function init() {
    buildUser(); buildStock(); buildCfg(); buildPkg(); buildInc();
    recalc();
  }
  buildOpt();
  init();
  const h0 = (location.hash || '').slice(1);
  if (h0 && $('#tab-' + h0)) showTab(h0);
})();
